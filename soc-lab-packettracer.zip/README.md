# Simple SOC Lab in Cisco Packet Tracer

## 📖 Overview
This lab simulates a mini SOC environment inside Cisco Packet Tracer:
- VLAN segmentation (Users, Servers, Attacker)
- Router-on-a-stick for inter-VLAN routing
- Syslog + DHCP + NTP on a central server
- SPAN (port mirroring) for IDS traffic capture
- Analyst workflow with logs and mirrored traffic

## 🖥️ Requirements
- Cisco Packet Tracer 8.2+
- PC/Server devices inside PT

## 📂 Repo Contents
- `lab-configs/` → CLI configs for router & switch
- `lab.pkt` → the complete Packet Tracer topology file (add your own)
- `lab-topology/` → optional diagrams

## 🚀 How to Use
1. Download this repo as ZIP or `git clone`.
2. Open `lab.pkt` in Packet Tracer.
3. Load configs from `lab-configs` if needed.
4. Verify connectivity:
   - Analyst PC → Server (HTTP request)
   - Attacker PC → flood traffic
   - Logs on server’s Syslog tab

## 🛠️ Quick Test Commands
On R1:
```
show ip route
show ip interface brief
show logging
```

On CoreSw:
```
show vlan brief
show monitor session
```

On Analyst PC:
- Ping 192.168.20.10
- Browser → `http://192.168.20.10`

## 📦 Download
Click **Code → Download ZIP** or:
```
git clone https://github.com/YOUR-USERNAME/soc-lab-packettracer.git
```
